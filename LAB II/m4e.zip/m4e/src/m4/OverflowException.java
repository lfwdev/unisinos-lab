package m4;

public class OverflowException extends RuntimeException {
	public OverflowException() {
		super("Overflow!");
	}

}