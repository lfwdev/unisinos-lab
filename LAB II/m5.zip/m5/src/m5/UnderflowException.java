package m5;

public class UnderflowException extends RuntimeException {
	public UnderflowException() {
		super("Underflow!");
	}

}